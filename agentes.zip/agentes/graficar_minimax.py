import sys
import subprocess

# Auto-instalar dependencias si faltan
def instalar_dependencias():
    try:
        import networkx
        import matplotlib.pyplot as plt
    except ImportError:
        print("Instalando networkx y matplotlib...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "networkx", "matplotlib", "--quiet"])

instalar_dependencias()

import networkx as nx
import matplotlib.pyplot as plt
from AgentesConAdversario import sucesores, es_terminal, utilidad, MAX, MIN

def estado_a_string(estado):
    simbolos = {0: ' ', 1: 'X', -1: 'O'}
    fila1 = f"{simbolos[estado[0]]}|{simbolos[estado[1]]}|{simbolos[estado[2]]}"
    fila2 = f"{simbolos[estado[3]]}|{simbolos[estado[4]]}|{simbolos[estado[5]]}"
    fila3 = f"{simbolos[estado[6]]}|{simbolos[estado[7]]}|{simbolos[estado[8]]}"
    return f"{fila1}\n-----\n{fila2}\n-----\n{fila3}"

def construir_arbol(estado_inicial):
    G = nx.DiGraph()
    visitados = set()
    cola = [estado_inicial]
    G.add_node(estado_inicial, label=estado_a_string(estado_inicial))
    
    while cola:
        estado_actual = cola.pop(0)
        
        if estado_actual in visitados:
            continue
        visitados.add(estado_actual)
        
        if not es_terminal(estado_actual):
            for hijo in sucesores(estado_actual):
                if hijo not in G:
                    G.add_node(hijo, label=estado_a_string(hijo))
                G.add_edge(estado_actual, hijo)
                cola.append(hijo)
                
    return G

def mostrar_grafo(G):
    pos = nx.spring_layout(G, seed=42) # para intentar que se vea ordenado
    
    # Dibujar usando matplotlib
    plt.figure(figsize=(12, 8))
    
    # Obtener etiquetas
    labels = nx.get_node_attributes(G, 'label')
    
    # Colorear nodos terminales vs no terminales
    color_map = []
    for node in G:
        if es_terminal(node):
            if utilidad(node) == 1:
                color_map.append('lightgreen') # Gana X
            elif utilidad(node) == -1:
                color_map.append('lightcoral') # Gana O
            else:
                color_map.append('lightgrey')   # Empate
        else:
            color_map.append('lightblue')
            
    nx.draw(G, pos, labels=labels, node_color=color_map, with_labels=True, 
            node_size=3000, font_size=8, font_family='monospace', 
            arrows=True, arrowsize=20, node_shape='s')
            
    # Título y leyenda simples
    plt.title("Grafo de Estados del Tres en Raya (Minimax)")
    plt.axis("off") # apagar los ejes
    
    print("Mostrando el grafo en una ventana... ¡Ciérrala para continuar!")
    plt.show()

if __name__ == "__main__":
    # Escogemos un estado inicial casi terminado para que el grafo no sea gigantesco
    # X empieza, X e O han jugado varias veces.
    # Tablero inicial de prueba:
    # X | O | X
    # O | X |  
    # O |   |  
    estado_prueba = (
        1, -1, 1,
       -1,  1, 0,
       -1,  0, 0
    )
    
    print("Construyendo el árbol de decisiones...")
    grafo = construir_arbol(estado_prueba)
    print(f"Grafo construido con {grafo.number_of_nodes()} nodos y {grafo.number_of_edges()} aristas.")
    
    mostrar_grafo(grafo)
